--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE aeroport;
--
-- Name: aeroport; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE aeroport WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE aeroport OWNER TO postgres;

\connect aeroport

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AIRPORTS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AIRPORTS" (
    airport_code text NOT NULL,
    country text NOT NULL,
    status text NOT NULL,
    city text,
    name text NOT NULL,
    CONSTRAINT chk_airport_code_format CHECK ((airport_code ~ '^[A-Z]{3}$'::text)),
    CONSTRAINT chk_city_not_empty CHECK ((city <> ''::text)),
    CONSTRAINT chk_country_not_empty CHECK ((country <> ''::text)),
    CONSTRAINT chk_name_not_empty CHECK ((name <> ''::text)),
    CONSTRAINT chk_status CHECK ((status = ANY (ARRAY['Operational'::text, 'Closed'::text, 'UnderConstruction'::text, 'TemporarilyClosed'::text, 'LimitedOperations'::text, 'RestrictedAccess'::text, 'EmergencyMode'::text])))
);


ALTER TABLE public."AIRPORTS" OWNER TO postgres;

--
-- Name: CASH_REGISTERS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CASH_REGISTERS" (
    cash_register_id uuid NOT NULL,
    address text NOT NULL,
    status text NOT NULL,
    CONSTRAINT chk_address_not_empty CHECK ((address <> ''::text)),
    CONSTRAINT chk_status CHECK ((status = ANY (ARRAY['Open'::text, 'Closed'::text, 'InUse'::text, 'OutofService'::text, 'UnderMaintenance'::text, 'Reconciled'::text, 'AwaitingCash'::text])))
);


ALTER TABLE public."CASH_REGISTERS" OWNER TO postgres;

--
-- Name: COMPANY; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."COMPANY" (
    company_id uuid NOT NULL,
    name text NOT NULL,
    country text NOT NULL,
    CONSTRAINT chk_company_country_not_empty CHECK ((country <> ''::text)),
    CONSTRAINT chk_company_name_not_empty CHECK ((name <> ''::text))
);


ALTER TABLE public."COMPANY" OWNER TO postgres;

--
-- Name: CREW; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CREW" (
    crew_id uuid NOT NULL,
    role text NOT NULL,
    medical_check_date date NOT NULL,
    medical_status text NOT NULL,
    medical_reason text,
    flight_id uuid,
    CONSTRAINT chk_medical_check_date CHECK ((medical_check_date <= CURRENT_DATE)),
    CONSTRAINT chk_medical_reason_length CHECK ((length(medical_reason) <= 500)),
    CONSTRAINT chk_medical_status CHECK ((medical_status = ANY (ARRAY['FitforDuty'::text, 'UnfitforDuty'::text, 'OnSickLeave'::text, 'InQuarantine'::text, 'Recovered'::text, 'MedicalClearancePending'::text]))),
    CONSTRAINT chk_role_valid CHECK ((role = ANY (ARRAY['Pilot'::text, 'CoPilot'::text, 'FlightEngineer'::text, 'CabinCrew'::text])))
);


ALTER TABLE public."CREW" OWNER TO postgres;

--
-- Name: CREW_MEMBERS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CREW_MEMBERS" (
    member_id uuid NOT NULL,
    company_id uuid NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    phone_number text NOT NULL,
    passport_serial numeric NOT NULL,
    passport_number numeric NOT NULL,
    passport_region text NOT NULL,
    role text NOT NULL,
    CONSTRAINT chk_email_format CHECK ((email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text)),
    CONSTRAINT chk_full_name_not_empty CHECK ((full_name <> ''::text)),
    CONSTRAINT chk_passport_number CHECK (((passport_number)::text ~ '^\d{6,10}$'::text)),
    CONSTRAINT chk_passport_region_not_empty CHECK ((passport_region <> ''::text)),
    CONSTRAINT chk_passport_serial CHECK (((passport_serial)::text ~ '^\d{4,8}$'::text)),
    CONSTRAINT chk_role CHECK ((role = ANY (ARRAY['Pilot'::text, 'CoPilot'::text, 'FlightEngineer'::text, 'CabinCrew'::text, 'FlightAttendant'::text, 'Purser'::text, 'Navigator'::text, 'Dispatcher'::text, 'GroundSupport'::text, 'MaintenanceTechnician'::text])))
);


ALTER TABLE public."CREW_MEMBERS" OWNER TO postgres;

--
-- Name: FLIGHT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FLIGHT" (
    status text NOT NULL,
    flight_id uuid NOT NULL,
    plane_id uuid,
    arrival_time time with time zone NOT NULL,
    arrival_time_fact time with time zone,
    departure_time time with time zone NOT NULL,
    departure_time_fact time with time zone,
    departure_airport text NOT NULL,
    destination_airport text NOT NULL,
    CONSTRAINT chk_airports_different CHECK ((departure_airport <> destination_airport)),
    CONSTRAINT chk_arrival_after_departure CHECK ((arrival_time > departure_time)),
    CONSTRAINT chk_status CHECK ((status = ANY (ARRAY['Scheduled'::text, 'InProgress'::text, 'Completed'::text, 'Cancelled'::text, 'Delayed'::text, 'Diverted'::text, 'OnTime'::text, 'Boarding'::text])))
);


ALTER TABLE public."FLIGHT" OWNER TO postgres;

--
-- Name: PASSENGERS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PASSENGERS" (
    passenger_id uuid NOT NULL,
    full_name text NOT NULL,
    passport_serial integer NOT NULL,
    passport_number integer NOT NULL,
    passport_region text NOT NULL,
    birth_date date NOT NULL,
    phone_number numeric NOT NULL,
    email text NOT NULL,
    CONSTRAINT chk_birth_date CHECK ((birth_date <= CURRENT_DATE)),
    CONSTRAINT chk_full_name CHECK ((full_name ~ '\S+\s+\S+'::text)),
    CONSTRAINT chk_passenger_full_name_not_empty CHECK ((full_name <> ''::text)),
    CONSTRAINT chk_passport_number CHECK (((passport_number)::text ~ '^\d{6,10}$'::text)),
    CONSTRAINT chk_passport_region_not_empty CHECK ((passport_region <> ''::text)),
    CONSTRAINT chk_passport_serial CHECK (((passport_serial)::text ~ '^\d{4,8}$'::text))
);


ALTER TABLE public."PASSENGERS" OWNER TO postgres;

--
-- Name: PLANES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PLANES" (
    plane_id uuid NOT NULL,
    model_id uuid NOT NULL,
    company_id uuid NOT NULL,
    status text NOT NULL,
    flight_duration time without time zone NOT NULL,
    last_technical_service timestamp with time zone NOT NULL,
    CONSTRAINT chk_flight_duration_positive CHECK (((flight_duration)::interval > '00:00:00'::interval)),
    CONSTRAINT chk_last_technical_service CHECK ((last_technical_service <= CURRENT_TIMESTAMP)),
    CONSTRAINT chk_status CHECK ((status = ANY (ARRAY['InService'::text, 'OutofService'::text, 'MaintenanceRequired'::text, 'InRepair'::text, 'ScheduledforMaintenance'::text, 'Reserved'::text, 'Decommissioned'::text])))
);


ALTER TABLE public."PLANES" OWNER TO postgres;

--
-- Name: PLANE_MODELS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PLANE_MODELS" (
    model_id uuid NOT NULL,
    type text NOT NULL,
    seat_count integer NOT NULL,
    speed numeric NOT NULL,
    fuel_consumption numeric NOT NULL,
    cargo_capacity numeric NOT NULL,
    range numeric NOT NULL,
    role text NOT NULL,
    CONSTRAINT chk_type_not_empty CHECK ((type <> ''::text))
);


ALTER TABLE public."PLANE_MODELS" OWNER TO postgres;

--
-- Name: SEATS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SEATS" (
    seat_id uuid NOT NULL,
    flight_id uuid NOT NULL,
    seat_number text NOT NULL,
    seat_type text NOT NULL,
    base_price numeric DEFAULT 0 NOT NULL,
    is_booked boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_base_price_non_negative CHECK ((base_price >= (0)::numeric)),
    CONSTRAINT chk_seat_number CHECK ((seat_number ~ '^\d+[A-Za-z]$'::text)),
    CONSTRAINT chk_seat_type CHECK ((seat_type = ANY (ARRAY['Economy'::text, 'Business'::text, 'FirstClass'::text, 'PremiumEconomy'::text, 'Window'::text, 'Aisle'::text, 'Middle'::text, 'ExitRow'::text, 'Bulkhead'::text, 'Recliner'::text, 'NonRecliner'::text, 'Accessible'::text])))
);


ALTER TABLE public."SEATS" OWNER TO postgres;

--
-- Name: TICKETS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TICKETS" (
    ticket_id uuid NOT NULL,
    flight_id uuid NOT NULL,
    seat_id uuid NOT NULL,
    sale_channel text NOT NULL,
    cash_register_id uuid NOT NULL,
    status text NOT NULL,
    additional_fee numeric NOT NULL,
    passanger_id uuid NOT NULL,
    CONSTRAINT chk_additional_fee_non_negative CHECK ((additional_fee >= (0)::numeric)),
    CONSTRAINT chk_sale_channel CHECK ((sale_channel = ANY (ARRAY['Online'::text, 'TicketOffice'::text, 'TravelAgency'::text, 'MobileApp'::text, 'Kiosk'::text, 'CorporateBooking'::text, 'ThirdPartyVendor'::text, 'AirportCounter'::text]))),
    CONSTRAINT chk_ticket_status CHECK ((status = ANY (ARRAY['Available'::text, 'Booked'::text, 'Confirmed'::text, 'Cancelled'::text, 'CheckedIn'::text, 'NoShow'::text, 'Refunded'::text, 'PendingPayment'::text])))
);


ALTER TABLE public."TICKETS" OWNER TO postgres;

--
-- Name: TRANSIT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TRANSIT" (
    transit_id "char"[] NOT NULL,
    arrival_flight_id uuid NOT NULL,
    departure_flight_id uuid NOT NULL,
    CONSTRAINT chk_arrival_departure_different CHECK ((arrival_flight_id <> departure_flight_id))
);


ALTER TABLE public."TRANSIT" OWNER TO postgres;

--
-- Data for Name: AIRPORTS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AIRPORTS" (airport_code, country, status, city, name) FROM stdin;
\.
COPY public."AIRPORTS" (airport_code, country, status, city, name) FROM '$$PATH$$/3756.dat';

--
-- Data for Name: CASH_REGISTERS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CASH_REGISTERS" (cash_register_id, address, status) FROM stdin;
\.
COPY public."CASH_REGISTERS" (cash_register_id, address, status) FROM '$$PATH$$/3758.dat';

--
-- Data for Name: COMPANY; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."COMPANY" (company_id, name, country) FROM stdin;
\.
COPY public."COMPANY" (company_id, name, country) FROM '$$PATH$$/3763.dat';

--
-- Data for Name: CREW; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CREW" (crew_id, role, medical_check_date, medical_status, medical_reason, flight_id) FROM stdin;
\.
COPY public."CREW" (crew_id, role, medical_check_date, medical_status, medical_reason, flight_id) FROM '$$PATH$$/3765.dat';

--
-- Data for Name: CREW_MEMBERS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CREW_MEMBERS" (member_id, company_id, full_name, email, phone_number, passport_serial, passport_number, passport_region, role) FROM stdin;
\.
COPY public."CREW_MEMBERS" (member_id, company_id, full_name, email, phone_number, passport_serial, passport_number, passport_region, role) FROM '$$PATH$$/3764.dat';

--
-- Data for Name: FLIGHT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FLIGHT" (status, flight_id, plane_id, arrival_time, arrival_time_fact, departure_time, departure_time_fact, departure_airport, destination_airport) FROM stdin;
\.
COPY public."FLIGHT" (status, flight_id, plane_id, arrival_time, arrival_time_fact, departure_time, departure_time_fact, departure_airport, destination_airport) FROM '$$PATH$$/3755.dat';

--
-- Data for Name: PASSENGERS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PASSENGERS" (passenger_id, full_name, passport_serial, passport_number, passport_region, birth_date, phone_number, email) FROM stdin;
\.
COPY public."PASSENGERS" (passenger_id, full_name, passport_serial, passport_number, passport_region, birth_date, phone_number, email) FROM '$$PATH$$/3759.dat';

--
-- Data for Name: PLANES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PLANES" (plane_id, model_id, company_id, status, flight_duration, last_technical_service) FROM stdin;
\.
COPY public."PLANES" (plane_id, model_id, company_id, status, flight_duration, last_technical_service) FROM '$$PATH$$/3766.dat';

--
-- Data for Name: PLANE_MODELS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PLANE_MODELS" (model_id, type, seat_count, speed, fuel_consumption, cargo_capacity, range, role) FROM stdin;
\.
COPY public."PLANE_MODELS" (model_id, type, seat_count, speed, fuel_consumption, cargo_capacity, range, role) FROM '$$PATH$$/3762.dat';

--
-- Data for Name: SEATS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SEATS" (seat_id, flight_id, seat_number, seat_type, base_price, is_booked) FROM stdin;
\.
COPY public."SEATS" (seat_id, flight_id, seat_number, seat_type, base_price, is_booked) FROM '$$PATH$$/3760.dat';

--
-- Data for Name: TICKETS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TICKETS" (ticket_id, flight_id, seat_id, sale_channel, cash_register_id, status, additional_fee, passanger_id) FROM stdin;
\.
COPY public."TICKETS" (ticket_id, flight_id, seat_id, sale_channel, cash_register_id, status, additional_fee, passanger_id) FROM '$$PATH$$/3761.dat';

--
-- Data for Name: TRANSIT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TRANSIT" (transit_id, arrival_flight_id, departure_flight_id) FROM stdin;
\.
COPY public."TRANSIT" (transit_id, arrival_flight_id, departure_flight_id) FROM '$$PATH$$/3757.dat';

--
-- Name: AIRPORTS AIRPORTS_airport_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AIRPORTS"
    ADD CONSTRAINT "AIRPORTS_airport_code_key" UNIQUE (airport_code);


--
-- Name: AIRPORTS AIRPORTS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AIRPORTS"
    ADD CONSTRAINT "AIRPORTS_pkey" PRIMARY KEY (airport_code);


--
-- Name: CASH_REGISTERS CASH_REGISTERS_cash_register_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CASH_REGISTERS"
    ADD CONSTRAINT "CASH_REGISTERS_cash_register_id_key" UNIQUE (cash_register_id);


--
-- Name: CASH_REGISTERS CASH_REGISTERS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CASH_REGISTERS"
    ADD CONSTRAINT "CASH_REGISTERS_pkey" PRIMARY KEY (cash_register_id);


--
-- Name: COMPANY COMPANY_company_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."COMPANY"
    ADD CONSTRAINT "COMPANY_company_id_key" UNIQUE (company_id);


--
-- Name: COMPANY COMPANY_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."COMPANY"
    ADD CONSTRAINT "COMPANY_pkey" PRIMARY KEY (company_id);


--
-- Name: CREW_MEMBERS CREW_MEMBERS_member_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW_MEMBERS"
    ADD CONSTRAINT "CREW_MEMBERS_member_id_key" UNIQUE (member_id);


--
-- Name: CREW_MEMBERS CREW_MEMBERS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW_MEMBERS"
    ADD CONSTRAINT "CREW_MEMBERS_pkey" PRIMARY KEY (member_id);


--
-- Name: CREW CREW_crew_id_flight_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW"
    ADD CONSTRAINT "CREW_crew_id_flight_id_key" UNIQUE (crew_id, flight_id);


--
-- Name: CREW CREW_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW"
    ADD CONSTRAINT "CREW_pkey" PRIMARY KEY (crew_id);


--
-- Name: FLIGHT FLIGHT_flight_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FLIGHT"
    ADD CONSTRAINT "FLIGHT_flight_id_key" UNIQUE (flight_id);


--
-- Name: FLIGHT FLIGHT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FLIGHT"
    ADD CONSTRAINT "FLIGHT_pkey" PRIMARY KEY (flight_id);


--
-- Name: PASSENGERS PASSENGERS_passenger_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PASSENGERS"
    ADD CONSTRAINT "PASSENGERS_passenger_id_key" UNIQUE (passenger_id);


--
-- Name: PASSENGERS PASSENGERS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PASSENGERS"
    ADD CONSTRAINT "PASSENGERS_pkey" PRIMARY KEY (passenger_id);


--
-- Name: PLANES PLANES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PLANES"
    ADD CONSTRAINT "PLANES_pkey" PRIMARY KEY (plane_id);


--
-- Name: PLANES PLANES_plane_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PLANES"
    ADD CONSTRAINT "PLANES_plane_id_key" UNIQUE (plane_id);


--
-- Name: PLANE_MODELS PLANE_MODELS_model_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PLANE_MODELS"
    ADD CONSTRAINT "PLANE_MODELS_model_id_key" UNIQUE (model_id);


--
-- Name: PLANE_MODELS PLANE_MODELS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PLANE_MODELS"
    ADD CONSTRAINT "PLANE_MODELS_pkey" PRIMARY KEY (model_id);


--
-- Name: SEATS SEATS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SEATS"
    ADD CONSTRAINT "SEATS_pkey" PRIMARY KEY (seat_id);


--
-- Name: SEATS SEATS_seat_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SEATS"
    ADD CONSTRAINT "SEATS_seat_id_key" UNIQUE (seat_id);


--
-- Name: TICKETS TICKETS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKETS"
    ADD CONSTRAINT "TICKETS_pkey" PRIMARY KEY (ticket_id);


--
-- Name: TICKETS TICKETS_ticket_id_seat_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKETS"
    ADD CONSTRAINT "TICKETS_ticket_id_seat_id_key" UNIQUE (ticket_id, seat_id);


--
-- Name: TRANSIT TRANSIT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TRANSIT"
    ADD CONSTRAINT "TRANSIT_pkey" PRIMARY KEY (transit_id);


--
-- Name: TRANSIT TRANSIT_transit_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TRANSIT"
    ADD CONSTRAINT "TRANSIT_transit_id_key" UNIQUE (transit_id);


--
-- Name: CREW_MEMBERS chk_phone_number; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public."CREW_MEMBERS"
    ADD CONSTRAINT chk_phone_number CHECK ((phone_number ~ '^\+?[0-9]{6,}$'::text)) NOT VALID;


--
-- Name: PASSENGERS chk_phone_number; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public."PASSENGERS"
    ADD CONSTRAINT chk_phone_number CHECK (((phone_number)::text ~ '^[0-9]{6,}$'::text)) NOT VALID;


--
-- Name: CREW_MEMBERS CREW_MEMBERS_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW_MEMBERS"
    ADD CONSTRAINT "CREW_MEMBERS_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."COMPANY"(company_id);


--
-- Name: CREW CREW_crew_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW"
    ADD CONSTRAINT "CREW_crew_id_fkey" FOREIGN KEY (crew_id) REFERENCES public."CREW_MEMBERS"(member_id);


--
-- Name: CREW CREW_flight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CREW"
    ADD CONSTRAINT "CREW_flight_id_fkey" FOREIGN KEY (flight_id) REFERENCES public."FLIGHT"(flight_id);


--
-- Name: FLIGHT FLIGHT_departure_airport_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FLIGHT"
    ADD CONSTRAINT "FLIGHT_departure_airport_fkey" FOREIGN KEY (departure_airport) REFERENCES public."AIRPORTS"(airport_code) NOT VALID;


--
-- Name: FLIGHT FLIGHT_destination_airport_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FLIGHT"
    ADD CONSTRAINT "FLIGHT_destination_airport_fkey" FOREIGN KEY (destination_airport) REFERENCES public."AIRPORTS"(airport_code) NOT VALID;


--
-- Name: FLIGHT FLIGHT_plane_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FLIGHT"
    ADD CONSTRAINT "FLIGHT_plane_id_fkey" FOREIGN KEY (plane_id) REFERENCES public."PLANES"(plane_id) NOT VALID;


--
-- Name: PLANES PLANES_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PLANES"
    ADD CONSTRAINT "PLANES_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."COMPANY"(company_id);


--
-- Name: PLANES PLANES_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PLANES"
    ADD CONSTRAINT "PLANES_model_id_fkey" FOREIGN KEY (model_id) REFERENCES public."PLANE_MODELS"(model_id);


--
-- Name: SEATS SEATS_flight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SEATS"
    ADD CONSTRAINT "SEATS_flight_id_fkey" FOREIGN KEY (flight_id) REFERENCES public."FLIGHT"(flight_id);


--
-- Name: TICKETS TICKETS_cash_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKETS"
    ADD CONSTRAINT "TICKETS_cash_register_id_fkey" FOREIGN KEY (cash_register_id) REFERENCES public."CASH_REGISTERS"(cash_register_id);


--
-- Name: TICKETS TICKETS_flight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKETS"
    ADD CONSTRAINT "TICKETS_flight_id_fkey" FOREIGN KEY (flight_id) REFERENCES public."FLIGHT"(flight_id);


--
-- Name: TICKETS TICKETS_passanger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKETS"
    ADD CONSTRAINT "TICKETS_passanger_id_fkey" FOREIGN KEY (passanger_id) REFERENCES public."PASSENGERS"(passenger_id);


--
-- Name: TICKETS TICKETS_seat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKETS"
    ADD CONSTRAINT "TICKETS_seat_id_fkey" FOREIGN KEY (seat_id) REFERENCES public."SEATS"(seat_id);


--
-- Name: TRANSIT TRANSIT_arrival_flight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TRANSIT"
    ADD CONSTRAINT "TRANSIT_arrival_flight_id_fkey" FOREIGN KEY (arrival_flight_id) REFERENCES public."FLIGHT"(flight_id) NOT VALID;


--
-- Name: TRANSIT TRANSIT_departure_fligh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TRANSIT"
    ADD CONSTRAINT "TRANSIT_departure_fligh_id_fkey" FOREIGN KEY (departure_flight_id) REFERENCES public."FLIGHT"(flight_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

